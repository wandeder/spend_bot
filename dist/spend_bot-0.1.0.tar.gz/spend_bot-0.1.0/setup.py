# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['spend_bot']

package_data = \
{'': ['*']}

install_requires = \
['DateTime>=4.5,<5.0',
 'aiogram>=2.21,<3.0',
 'pygsheets>=2.0.5,<3.0.0',
 'python-dotenv>=0.20.0,<0.21.0']

setup_kwargs = {
    'name': 'spend-bot',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Dmitrii Morozov',
    'author_email': '33morozov@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
